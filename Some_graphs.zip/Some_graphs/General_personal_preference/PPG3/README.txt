INFO

General model trained, tested and evaluated on 100 000 data points
20% of the data was weighed with preferences such as 

- liking nights/weekends
- not liking nights/weekends

This model is loaded and the 3 first layers are frozen while only the last one is re-trained
The model is trained on data from the clear preferences to see whether the model can learn those, but also when it learns those. 
